import React from 'react';

import './App.css';
class Reactplaychild extends React.Component
{
  constructor(props){
    super(props)
    this.state={
  valueChild:""
    }
  }
  onChange=(e)=>{
      this.props.textvalues(e.target.value)
//  this.setState({
//      valueChild:e.target.value
//  })   

 console.log("valuechild========",this.state.valueChild);
 
  }
  render()
{
  return(
   <div>
     <h1>
 <input
 
 
 onChange={
     this.onChange
 }
 >
 </input>
     </h1>
   </div>
  )
}
}
export default Reactplaychild;
